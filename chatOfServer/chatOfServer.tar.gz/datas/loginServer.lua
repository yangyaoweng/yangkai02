local skynet = require "skynet"

local netpack = require "netpack"
local socket = require "socket"
local mysql = require "mysql"
local redis = require "redis"

--local sharedata = require "sharedata"
local datacenter = require "datacenter"
require "gameG"

local CMD = {}
--唯一登录用
local client_fds={}
local auto_id=0
local talk_users={}

------------redis
local conf = {
	host = "127.0.0.1" ,
	port = 6379 ,
	db = 0
}
local confTM ={
  host = "127.0.0.1" ,
  port = 6379 ,
  db = 1
} 
-------------redis与mysql组合
function useronline(client_fd,dbrkey,names)
  auto_id=auto_id+1
  print("添加用户名****")
  local userInfo = {
    userid = auto_id,
    name = names,
    dbrkey = dbrkey,
  }
  --新用户
  talk_users[userInfo.userid]=userInfo
  client_fds[userInfo.userid]=client_fd
  return "yes"
end
--判断用户是否已经登录
function isUser(name)
  print("判断用户名是否存在")
  for userid in pairs(talk_users) do
    if talk_users[userid].name==name then
      print("用户名存在")
      return true , talk_users[userid].dbrkey
    end
  end
  print("用户名不存在")
  return false
end
--用户断开
function CMD.rmUser(dbm,dbr,dbrT,client_fd)
  for userid in pairs(client_fds) do
    if client_fds[userid]==client_fd then
--      for userid2 in pairs(client_fds) do --广播
--        socket.write(client_fds[userid2], netpack.pack(skynet.pack(1,1011,protobuf.encode("talkbox.talk_result",{id=userid}))))
--      end
      --用户下线
      print("--------------下线----------", talk_users[userid].dbrkey)
      talk_users[userid]=nil
      client_fds[userid]=nil
    end
  end
end
------------------------------------------------------------

--1使用进行注册 CMD.mysqlServer01(dbm,dbr,dbrT,client_fd,talk_logins)
function CMD.mysqlServer01(dbm,dbr,dbrT,client_fd,talk_logins)
  local a = os.clock() 
  local talk_login = unserialize(talk_logins)
    print("用户正常登录")
--     local talk_login = {
--      name = "yan",
--      passwords = "23452345",
--    }
    local user03 = {}
    local userd1,userd2 = isUser(talk_login.name)
    if userd1 then
      print("已经存在该用户")
      return "ok",serialize({msg = "用户重复登录"})
    end
    local luas = "call userLongin01("
    luas = luas ..dbmL.lr..talk_login.name ..dbmL.lz..talk_login.passwords..dbmL.lr..')'
    local res = dbm:query(luas)
    print("数据库得到数据----",luas)
    print("数据库得到数据----",dump(res))
    if res[1][1]["row_key"] == "no"  then
      print("判断为no，需要创建宠物")
--      print(dump(res))
      return res[1][1],serialize(res[2])
    elseif res[1][1]["row_key"]== "yes" then
      print("判断为yes")
      --用户成功登录
      --将数据写入redis数据库
      --通过userId和记录id组成唯一的数据查找id
        local userInfo = {}
        print("---------")
        print("得到用户键名:",res[2][1][cli_user[2]])
        if (dbr:hlen(res[2][1][cli_user[2]]))~= 0 then
          print("键存在")

          --从redis获取用户信息
          local userw = dbr:hmget(res[2][1][cli_user[2]],cli_user[1],cli_user[2],cli_user[3],cli_user[4],cli_user[5],cli_user[6],cli_user[7],cli_user[8],cli_user[9],cli_user[10],cli_user[11],cli_user[12],cli_user[13],cli_user[14], cli_user[17])
          local userw2 = dbr:hmget(res[2][1][cli_user[2]],1,2,3,4,5,6,7,8)
          user_item[res[2][1][cli_user[2]] ] = {[1]= userw2[1],[2]= userw2[2],[3]= userw2[3], [4]=userw2[4], [5]= userw2[5], [6]= userw2[6], [7]= userw2[7], [8]= userw2[8]}
          --记录道具信息
          datacenter.set(res[2][1][cli_user[2]]..cli_user_k[1],user_item[res[2][1][cli_user[2]] ])
          print("道具信息----",dump(datacenter.get(res[2][1][cli_user[2]]..':'.."item") ) )
           --获取宠物信息
           for k,v in pairs(res[3]) do
            if type(v) == "table" then
              print("宠物名",v[tableRoleS[4]])
              table.insert(userInfo, {id = v[tableRoleS[2]], rolekey = v[tableRoleS[3]]})
            end
          end
           --数据组装
          for k,v in pairs(cli_user02) do
            if k == "dbrkey" or k == "roleopen" or k == "userGame" then
              user03[k] = userw[v]
            else
              user03[k] = tonumber( userw[v])
            end
          end
          user03["rolekey"] = userInfo
          --当前宠物信息
         local opens = dbr:hmget(userw[12], tableRoleS[2], tableRoleS[4], tableRoleS[5], tableRoleS[6], tableRoleS[7], tableRoleS[8], tableRoleS[9],tableRoleS[10])
         user03["currRole"] = {id =tonumber(opens[1]), name = opens[2], stageId = tonumber(opens[3]), stage = tonumber(opens[4]), life = tonumber(opens[5]),userLife = tonumber(opens[6]),levelCap = tonumber(opens[7]), restoreLife = tonumber(opens[8])}
          
          local b = os.clock()
          print(b-a)
          user_names[res[2][1] [cli_user[2]] ] = clone(user03)
          --sharedata.new(res[2][1][cli_user[2]], user03)
          --记录用户数据
          datacenter.set(res[2][1] [cli_user[2]],user03)
          useronline(client_fd,res[2][1] [cli_user[2]],talk_login.name)
          print("新建的----",dump(datacenter.get(res[2][1] [cli_user[2]]) ) )
          return res[1][1] ,serialize(user03)
        else
          print("键不存在")
          --创建用户键
          local userdb = res[2][1]
          local userItem = res[4][1]
          local rer2 = dbr:hmset(userdb[cli_user[2]], cli_user[1], userdb[cli_user[1]],cli_user[2], userdb[cli_user[2]],cli_user[3], userdb[cli_user[3]],cli_user[4], userdb[cli_user[4]], cli_user[5], userdb[cli_user[5]], cli_user[6],userdb[cli_user[6]], cli_user[7],userdb[cli_user[7]], cli_user[8],userdb[cli_user[8]], cli_user[9],userdb[cli_user[9]], cli_user[10],userdb[cli_user[10]], cli_user[11],userdb[cli_user[11]], cli_user[12],userdb[cli_user[12]], cli_user[13],userdb[cli_user[13]], cli_user[14],userdb[cli_user[14]], cli_user[17],userdb[cli_user[17]] )
          local rer3 = dbr:hmset(userdb[cli_user[2]],1,userItem[tableItemTable[2]],2,userItem[tableItemTable[3]],3,userItem[tableItemTable[4]], 4,userItem[tableItemTable[5]], 5,userItem[tableItemTable[6]], 6,userItem[tableItemTable[7]], 7,userItem[tableItemTable[8]], 8,userItem[tableItemTable[9]])
         user_item[userdb[cli_user[2]] ] = {[1]= userItem[tableItemTable[2]],[2]=userItem[tableItemTable[3]],[3]=userItem[tableItemTable[4]],[4]=userItem[tableItemTable[5]], [5]=userItem[tableItemTable[6]], [6]=userItem[tableItemTable[7]], [7]=userItem[tableItemTable[8]], [8]=userItem[tableItemTable[9]]}
          --每日完成任务数//和新建的键
          local res5 = dbr:hmset(userdb[cli_user[2]],cli_user_t[1],0,cli_user_t[2],0,cli_user_t[3],0,cli_user_t[4], userdb[cli_user_t[4]],cli_user_t[5], userdb[cli_user_t[5]],cli_user_t[6], userdb[cli_user_t[6]],cli_user_t[7], userdb[cli_user_t[7]],cli_user_t[8], userdb[cli_user_t[8]], cli_user_t[9],1 )
          if rer2 == "OK" then
            print("用户键创建成功")
          else
            print("用户键创建失败用户需要重新登录")
          end
          --创建宠物信息
          for k,v in pairs(res[3]) do
            print("---",k,v)
            if type(v) == "table" then
              print("宠物名",v[tableRoleS[4]])
              local varl = {id = v[tableRoleS[1]],rolekey = v[tableRoleS[3]]}
              table.insert(userInfo,varl)
              local rer = dbr:hmset(v[tableRoleS[3]],tableRoleS[1],v[tableRoleS[1]],tableRoleS[2],v[tableRoleS[2]],tableRoleS[3],v[tableRoleS[3]],tableRoleS[4],v[tableRoleS[4]],tableRoleS[5],v[tableRoleS[5]],tableRoleS[6],v[tableRoleS[6]], tableRoleS[7],v[tableRoleS[7]],tableRoleS[8],v[tableRoleS[8]],tableRoleS[9],v[tableRoleS[9]],tableRoleS[10],v[tableRoleS[10]],tableRoleS[11],v[tableRoleS[11]],tableRoleS[12],v[tableRoleS[12]], tableRoleS[13],v[tableRoleS[13]], tableRoleS[14],v[tableRoleS[14]],tableRoleS[15],v[tableRoleS[15]], tableRoleS[16],v[tableRoleS[16]], tableRoleS[17],v[tableRoleS[17]],tableRoleS[18],v[tableRoleS[18]],tableRoleS[19],v[tableRoleS[19]] )
            
               if rer == "OK" then
                print("用户键创建成功")
              else
                print("用户键创建失败用户需要重新登录")
              end
            end
          end
          print("这里返回数据")
         local userw = dbr:hmget(userdb[cli_user[2]],cli_user[1],cli_user[2],cli_user[3],cli_user[4],cli_user[5],cli_user[6],cli_user[7],cli_user[8],cli_user[9],cli_user[10],cli_user[11],cli_user[12],cli_user[13],cli_user[14],cli_user[17])
         local opens = dbr:hmget(userw[12], tableRoleS[2], tableRoleS[4], tableRoleS[5], tableRoleS[6], tableRoleS[7], tableRoleS[8], tableRoleS[9],tableRoleS[10])
         for k,v in pairs(cli_user02) do
            if k == "dbrkey" or k == "roleopen"  or k == "userGame" then
              user03[k] = userw[v]
            else
              user03[k] = tonumber( userw[v])
            end
          end
         user03["rolekey"] = userInfo
         user03["currRole"] = {id =tonumber(opens[1]), name = opens[2], stageId = tonumber(opens[3]), stage = tonumber(opens[4]), life = tonumber(opens[5]),userLife = tonumber(opens[6]),levelCap = tonumber(opens[7]), restoreLife = tonumber(opens[8])}
         user_names[userdb[cli_user[2]]] = user03
         datacenter.set(res[2][1] [cli_user[2]],user03)
         useronline(client_fd,res[2][1] [cli_user[2]],talk_login.name)
         print("新建的----",dump(user_names))
          return res[1][1] ,serialize(user03)
        end
    end
    
end

--1.1用户再次进入主界面时触发CMD.loginServer0101(dbm,dbr,dbrT,client_fd,talk_logins)
function CMD.loginServer0101(dbm,dbr,dbrT,client_fd,talk_logins)
  local a = os.clock() 
  print("再次进入主界面")
  --1用户再次登录
  local talk_login = unserialize(talk_logins)
--  local talk_login = {
--    dbrkey = "33:12",
--    userId = 33,
--    pass = 315,
--    roleopen = "33:12:20",
--  }
  --从缓存中读取更新的数据
--  local obj = sharedata.query(talk_login.dbrkey)
--  print(dump(obj))
--  user_names[talk_login.dbrkey] =obj
  local obj =datacenter.get(talk_login.dbrkey)
  print("用户角色信息",dump(obj))
  user_names[talk_login.dbrkey] =obj
  print("再次",dump(user_names))
    --2判断用户输入是否正确
  if talk_login.userId == user_names[talk_login.dbrkey][cli_user[1]] and talk_login.pass ==  user_names[talk_login.dbrkey][cli_user[9]] and talk_login.roleopen ==  user_names[talk_login.dbrkey][cli_user[12]] then
    --3输入正确可以使用
    print("正确返回主界面")
    print(dump(user_names[talk_login.dbrkey]))
    --1.1判断用户的宝气值是否大于最高宝气值
    if user_names[talk_login.dbrkey][cli_user[4]] < user_names[talk_login.dbrkey][cli_user[5]] then
      print("最高宝气值小于当前宝气值")
      user_names[talk_login.dbrkey][cli_user[4]] = user_names[talk_login.dbrkey][cli_user[5]]
      print(user_names[talk_login.dbrkey][cli_user[2]], cli_user[4], user_names[talk_login.dbrkey][cli_user[4]])
      local res011 = dbr:hset(user_names[talk_login.dbrkey][cli_user[2]], cli_user[4], user_names[talk_login.dbrkey][cli_user[4]])
      --判断缓存数据是否存在
      if trac_server[1] == nil then
        print("没有缓存数据")
        local luas = "call tardServer0102("
        luas = luas ..')'
        --print(luas)
        local res = dbm:query(luas)
        --print("my001----",dump(res))
        trac_server = res[1]
      else
        print("有缓存数据")
      end
      --print(dump(trac_server[user_names[talk_login.dbrkey][cli_user[3]]+1]))
      --1.2判断现在是否满足等级
      if trac_server[user_names[talk_login.dbrkey][cli_user[3]]+1][cli_user_t[10]] == nil then
        print("为最高等级")
      elseif trac_server[user_names[talk_login.dbrkey][cli_user[3]]+1][cli_user_t[10]] < user_names[talk_login.dbrkey][cli_user[4]] then
        print("达到升级要求")
        local res011 = dbr:hincrby(user_names[talk_login.dbrkey][cli_user[2]], cli_user[3],1)
        user_names[talk_login.dbrkey][cli_user[3]] = res011
        --的
        datacenter.set(talk_login.dbrkey, user_names[talk_login.dbrkey])
      else
        print("没有达到升级要求")
      end
    else
      print("最高宝气值大于当前宝气值")
    end

    local b = os.clock() 
    print(b-a)
    return "yes",serialize(user_names[talk_login.dbrkey])
  else
    print("输入不正确或用户还未登录")
    local b = os.clock() 
    print(b-a)
    return "no",{id = 902}
  end
end

--1.2使用临时用户创建宠物  CMD.mysqlCreateROle02(dbm,dbr,dbrT,client_fd,talk_login)
function CMD.mysqlCreateROle02(dbm,dbr,dbrT,client_fd,talk_logins)
    print("用户正常登入后")
    local talk_login = unserialize(talk_logins)
--    local talk_login = {
--      name = "Bob",
--      passwords = "123",
--      sex = 1,
--      roles = 1,
--    }
    local user03 = {}
    --查询mysql数据库
    local luas = "call userRoleCreate02("
    luas = luas ..dbmL.lr..talk_login.name ..dbmL.lz..talk_login.passwords..dbmL.lz2..talk_login.roles..')'
    print(luas)
    local res = dbm:query(luas)
    print("my001----",dump(res))
    if res[1][1]["row_key"] == "yes" then
      print("用户创建成功")
      return {id = 8}
    elseif res[1][1]["row_key"]  == "no" then
      print("用户不存在创表内")
      return {id = 11}
    else
      print("出现异常")
      return {id = 902}
    end
  return user03
end


--2宝气值界面 CMD.treaServer0102(dbm,dbr,dbrT,client_fd,talk_logins)
function CMD.treaServer0102(dbm,dbr,dbrT,client_fd,talk_logins)
  local a = os.clock() 
  local talk_login = unserialize(talk_logins)
  print("2宝气值界面")
  --1用户再次登录
--  local talk_login = {
--      dbrkey = "33:12",
--    }
  --从缓存中读取更新的数据
  local obj =datacenter.get(talk_login.dbrkey)
  print("用户角色信息",dump(obj))
  user_names[talk_login.dbrkey] =obj
    --1得到当前用户的最高宝气值和当前宝气值在判断缓存是否有数据
    if user_names[talk_login.dbrkey] == nil then
      print("用户还没有登录")
      return "no",{id = 903}
    end
    print("dddddddd")
    print(dump(trac_server))
    if trac_server[1] == nil then
      print("没有缓存数据")
      local luas = "call tardServer0102("
      luas = luas ..')'
      --print(luas)
      local res = dbm:query(luas)
      --print("my001----",dump(res))
      trac_server = res[1]
    else
      print("有缓存数据")
    end
    print(dump({gasNo = user_names[talk_login.dbrkey][cli_user[3]], gasValues = user_names[talk_login.dbrkey][cli_user[4]],usegasValues = user_names[talk_login.dbrkey][cli_user[5]], trea = trac_server}))
    --2返回数据当前用户的最高宝气值和当前宝气值和缓存数据
    return "yes",serialize({gasNo = user_names[talk_login.dbrkey][cli_user[3]], gasValues = user_names[talk_login.dbrkey][cli_user[4]],usegasValues = user_names[talk_login.dbrkey][cli_user[5]], trea = trac_server})
end

--------------------------------------------------------------------------
skynet.start(function()
	local dbm=mysql.connect{
		host="127.0.0.1",
		port=3306,
		database="skynet",
		user="root",
		password="root",
		max_packet_size = 1024 * 1024
	}
	if not dbm then
		print("failed to connect")
	end
	--表示连接成功
	print("连接成功")
  	--编码格式
	dbm:query("set names utf8")
	-----redis
	local dbr = redis.connect(conf)
	local dbrT = redis.connect(confTM)
--	ItemsMap(dbm,dbr,dbrT)
--  mysqlServer01(dbm,dbr,dbrT)
--  loginServer0101(dbm,dbr,dbrT)
--  treaServer0102(dbm,dbr,dbrT)
--mysqlServer01(dbm,dbr,dbrT)

	
	skynet.register "loginServer"
	--dbm:disconnect()
	--skynet.exit()
	skynet.dispatch("lua", function(session, address, cmd, ...)
		local f = CMD[cmd]
		skynet.ret(skynet.pack(f(dbm,dbr,dbrT,...)))
	
	
	end)
end)



